Dylan Brown
CSE 3461
Minilab 1
Student ID: 200148626

How to compile the code: type "make" in the console

How to run the code: 

- cd into the directory

- type ./server PORTNUMBER
	- sub PORTNUMBER for the port you wish to use

- in another terminal, type ./client localhost PORTNUMBER
	- use the same port number as before

- when the connection is established, type the word you wish to send into the console.
